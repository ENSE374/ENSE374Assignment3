package a3;


public enum Insurance {

	PlanA,
	PlanB,
	PlanC,
	UNKNOWN;

}
