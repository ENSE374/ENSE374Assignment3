package a3;

import java.io.IOException;
import java.util.*;

public class main {

	public static void main(String[] args) throws IOException {
		ArrayList<String> p_medicalHistory = new ArrayList<String>();
		///import medicalhistory from external file
		p_medicalHistory.add("History example1");
		p_medicalHistory.add("History example2");
		p_medicalHistory.add("History example3");
		
		Patient p1 = new Patient("david", "huo", "address","email",12,"123-456-7890","password","username",true,
				123456,"NULL","NULL","NULL",p_medicalHistory,Insurance.PlanA);
		Patient p2 = new Patient("Xiaojie", "Chen", "address","email",12,"123-456-7890","password","username",true,
				123456,"NULL","NULL","NULL",p_medicalHistory,Insurance.UNKNOWN);
		p1.setAllergicDrugs("eggs");
		p1.setMedicalForm("Medical form example1");
		p1.displayInfo();
		
		p2.displayInfo();
		p2.setPlan(Insurance.PlanC);
		p2.displayInfo();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		Doctor d = new Doctor("jin", "chen", "address","email",12,"123-456-7890","password","username",true,
				123456,"pos",true);
		d.displayInfo();
		d.addWorkplace(p1); 
		d.addWorkplace(p2); 
		d.displayWorkPlace();
		
		d.searchMedicalHistory(p1);
		
		
		
		
		
		
		
/*		Patient p = new Patient("david", "huo", "address","email",12,"123-456-7890","password","username",true,
				123456,"drugs","note","form");
		p.displayInfo();
		System.out.println("\n");
		
		Doctor d = new Doctor("jin", "chen", "address","email",12,"123-456-7890","password","username",true,
				123456,"pos",true);
		d.displayInfo();
		System.out.println("\n");
		
		Admin a = new Admin("jin", "chen", "address","email",12,"123-456-7890","password","username",true,
				123456,"pos");
		a.displayInfo();
		System.out.println("\n");
		
		MedicalHistory m = new MedicalHistory("david", "huo", "address","email",12,"123-456-7890","password","username",true,
				123456,"drugs","note","form","UNKNOWN");
		m.searchMedicalHistory(p);*/
	}

}
