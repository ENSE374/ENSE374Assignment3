package a3;

import java.util.*;

public class Patient extends User {
	
	private int patientID;
	private String allergicDrugs;
	private String doctorNote;
	private String medicalForm;
	private ArrayList<String> medicalHistory;
	private Insurance plan;
	public Patient(String firstname, String lastname, String address, String email, int age,
			String phoneNumber, String password, String username, Boolean isOnline, int patientID1, String allergicDrugs, String doctorNote, String medicalForm, ArrayList<String> medicalHistory, Insurance plan)
	{
		super(firstname, lastname, address, email, age, phoneNumber, password, username, isOnline);
		patientID=patientID1;
		this.allergicDrugs = allergicDrugs;
		this.doctorNote = doctorNote;
		this.medicalForm = medicalForm;
		this.medicalHistory = medicalHistory;
		this.plan = plan;
	}
	
	public void setPatientID(int patientID)
	{
		this.patientID = patientID;
	}
	
	public int getPatientID()
	{
		return patientID;
	}
	public void displayInfo()
	{
		super.displayInfo();
		System.out.println("Patient ID: "+patientID);
		System.out.println("Allergic drugs: "+allergicDrugs);
		System.out.println("Doctor note: "+doctorNote);
		System.out.println("Medical form: "+medicalForm);
		System.out.println("Medical history: "+medicalHistory);
		System.out.println("Insurance: " + plan);
		System.out.println();
	}

	public ArrayList<String> getMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(ArrayList<String> medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public String getMedicalForm() {
		return medicalForm;
	}

	public void setMedicalForm(String medicalForm) {
		this.medicalForm = medicalForm;
	}

	public String getDoctorNote() {
		return doctorNote;
	}

	public void setDoctorNote(String doctorNote) {
		this.doctorNote = doctorNote;
	}

	public String getAllergicDrugs() {
		return allergicDrugs;
	}

	public void setAllergicDrugs(String allergicDrugs) {
		this.allergicDrugs = allergicDrugs;
	}

	public Insurance getPlan() {
		return plan;
	}

	public void setPlan(Insurance plan) {
		this.plan = plan;
	}

	
}
